﻿// Author: Bodvar JONSSON
// Email: bjblackbelt@gmail.com
// Telephone Number: 0858204129
//
//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;

using System;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using BankLibrary;

namespace Fusion
{
    public partial class FusionForm : BankUIForm
    {
        // object for serializing RecordSerializables in binary format
        private BinaryFormatter formatter = new BinaryFormatter();
        private FileStream output; // stream for writing to a file

        // This is from the Read Version:
        // object for deserializing RecordSerializable in binary format
        private BinaryFormatter reader = new BinaryFormatter();
        private FileStream input; // stream for reading from a file

        public FusionForm()
        {
            InitializeComponent();
        }

        // handler for saveButton_Click
        private void saveButton_Click(object sender, EventArgs e)
        {
            // create and show dialog box enabling user to save file
            DialogResult result;
            string fileName; // name of file to save data

            using (SaveFileDialog fileChooser = new SaveFileDialog())
            {
                fileChooser.CheckFileExists = false; // let user create file

                // retrieve the result of the dialog box
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName; // get specified file name
            }

            // ensure that user clicked "OK"
            if (result == DialogResult.OK)
            {
                // show error if user specified invalid file
                if (string.IsNullOrEmpty(fileName))
                {
                    MessageBox.Show("Invalid File Name", "Error",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    // save file via FileStream if user specified valid file
                    try
                    {
                        // open file with write access
                        output = new FileStream(fileName,
                           FileMode.OpenOrCreate, FileAccess.Write);

                        // disable Save button and enable Enter button
                        saveButton.Enabled = false;
                        enterButton.Enabled = true;
                    }
                    catch (IOException)
                    {
                        // notify user if file could not be opened
                        MessageBox.Show("Error opening file", "Error",
                           MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // handler for enterButton Click
        private void enterButton_Click(object sender, EventArgs e)
        {
            // store TextBox values string array
            string[] values = GetTextBoxValues();

            // determine whether TextBox account field is empty
            if (!string.IsNullOrEmpty(values[(int)TextBoxIndices.Account]))
            {
                // store TextBox values in RecordSerializable and serialize it
                try
                {
                    // get account-number value from TextBox
                    int accountNumber = int.Parse(
                       values[(int)TextBoxIndices.Account]);

                    // determine whether accountNumber is valid
                    if (accountNumber > 0)
                    {
                        // RecordSerializable to serialize
                        var record = new RecordSerializable(accountNumber,
                           values[(int)TextBoxIndices.First],
                           values[(int)TextBoxIndices.Last],
                           decimal.Parse(values[(int)TextBoxIndices.Balance]));

                        // write Record to FileStream (serialize object)
                        formatter.Serialize(output, record);
                    }
                    else
                    {
                        // notify user if invalid account number
                        MessageBox.Show("Invalid Account Number", "Error",
                           MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (SerializationException)
                {
                    MessageBox.Show("Error Writing to File", "Error",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Invalid Format", "Error",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            ClearTextBoxes(); // clear TextBox values
        }

        // handler for exitButton Click
        private void exitButton_Click(object sender, EventArgs e)
        {
            // close file
            try
            {
                output?.Close(); // close FileStream
            }
            catch (IOException)
            {
                MessageBox.Show("Cannot close file", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Application.Exit();
        }

        private void CreateFileForm_Load(object sender, EventArgs e)
        {

        }

        // This is from the Read version:
        // invoked when user clicks the Open button
        private void openButton_Click(object sender, EventArgs e)
        {
            // create and show dialog box enabling user to open file
            DialogResult result; // result of OpenFileDialog
            string fileName; // name of file containing data

            using (OpenFileDialog fileChooser = new OpenFileDialog())
            {
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName; // get specified name
            }

            // ensure that user clicked "OK"
            if (result == DialogResult.OK)
            {
                ClearTextBoxes();

                // show error if user specified invalid file
                if (string.IsNullOrEmpty(fileName))
                {
                    MessageBox.Show("Invalid File Name", "Error",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    // create FileStream to obtain read access to file
                    input = new FileStream(
                       fileName, FileMode.Open, FileAccess.ReadWrite);







                    openButton.Enabled = false; // disable Open File button
                    nextButton.Enabled = true;  // enable Next Record button
                }
            }
        }

        // This one is an additional button from me:
        // invoked when user clicks Next button
        private void previousButton_Click(object sender, EventArgs e)
        {
            // deserialize RecordSerializable and store data in TextBoxes
            try
            {
                // get next RecordSerializable available in file
                RecordSerializable record =
                   (RecordSerializable)reader.Deserialize(input);

                // store RecordSerializable values in temporary string array
                var values = new string[] {
               record.Account.ToString(),
               record.FirstName.ToString(),
               record.LastName.ToString(),
               record.Balance.ToString()
            };

                // copy string-array values to TextBox values
                SetTextBoxValues(values);
            }
            catch (SerializationException)
            {
                input?.Close(); // close FileStream
                openButton.Enabled = true; // enable Open File button
                previousButton.Enabled = false; // disable Previous Record button
                nextButton.Enabled = false; 

                ClearTextBoxes();

                // notify user if no RecordSerializables in file
                MessageBox.Show("You have reached beginning of file", string.Empty,
                   MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // This one is from the read version too:
        // invoked when user clicks Next button
        private void nextButton_Click(object sender, EventArgs e)
        {
            // deserialize RecordSerializable and store data in TextBoxes
            try
            {
                // get next RecordSerializable available in file
                RecordSerializable record =
                   (RecordSerializable)reader.Deserialize(input);

                // store RecordSerializable values in temporary string array
                var values = new string[] {
               record.Account.ToString(),
               record.FirstName.ToString(),
               record.LastName.ToString(),
               record.Balance.ToString()
            };

                // copy string-array values to TextBox values
                SetTextBoxValues(values);
            }
            catch (SerializationException)
            {
                input?.Close(); // close FileStream
                openButton.Enabled = true; // enable Open File button
                nextButton.Enabled = false; // disable Next Record button
                previousButton.Enabled = false; // Something I added

                ClearTextBoxes();

                // notify user if no RecordSerializables in file
                MessageBox.Show("No more records in file", string.Empty,
                   MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
