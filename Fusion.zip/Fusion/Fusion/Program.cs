﻿// Author: Bodvar JONSSON
// Email: bjblackbelt@gmail.com
// Telephone Number: 0858204129
//
// General Description of Project:
// This project is basically a fusion of two projects from Chapter 17.
// One element is the project for creating a binary serial file.
// The other element is the project for opening and reading through 
// a binary serial file.
// In addition I have tried to add three functionalities, namely to go to 
// a previous record when reading from the .SER file, updating a record and 
// also deleting a record.
//
// What I have done so far as regards for implementing the 3 additional
// functionalities:
//
// I have modified the FileAccess.Read to FileAccess.ReadWrite, which should
// in theory not make modifying a record impossible.
//
// I have added a button for modifying a record.  What I need is to insert
// a corresponding method.
//
// I have added a button for going to a previous record.  Also I have copied 
// the methods and other code from the nextButton functionality, trying to 
// figre out how I could modify it in such a way that previousButton goes
// to a previous record when the 'Previous Record' button is pushed.  
// Could it be a question of modifying a + into a - sign in order to go backwards?
//
// I have added a button for deleting a record.  The method for implementing 
// the deletion is still to be added.  I have been looking for examples on the 
// internet, and my understanding is that due the the serial nature of the 
// binary database, it is not possible to surgically remove an individual record
// from the database. Instead the serial binary database needs to be constructed 
// all over again.
// 
// I would be grateful for your take on the these challenges that I am facing.
//
// Finally please note that I modified the BankLibrary in order for it to 
// fit to my theme for a data base, namely a vintage car rental.
// It is therefore important to use the BankLibrary I have provided when 
// trying out my project.



using System;
using System.Collections.Generic;
using System.Linq;
// using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fusion
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FusionForm());
        }
    }
}
