﻿// Author: Bodvar JONSSON
// Email: bjblackbelt@gmail.com
// Telephone Number: 0858204129
//

namespace Fusion
{
    partial class FusionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.enterButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.previousButton = new System.Windows.Forms.Button();
            this.nextButton = new System.Windows.Forms.Button();
            this.openButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // balanceTextBox
            // 
            this.balanceTextBox.Size = new System.Drawing.Size(153, 23);
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Size = new System.Drawing.Size(153, 23);
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Size = new System.Drawing.Size(153, 23);
            // 
            // accountTextBox
            // 
            this.accountTextBox.Size = new System.Drawing.Size(153, 23);
            // 
            // label4
            // 
            this.label4.Size = new System.Drawing.Size(113, 15);
            // 
            // label3
            // 
            this.label3.Size = new System.Drawing.Size(44, 15);
            // 
            // label2
            // 
            this.label2.Size = new System.Drawing.Size(62, 15);
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(89, 15);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(231, 232);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(86, 31);
            this.exitButton.TabIndex = 18;
            this.exitButton.Text = "Exit";
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // enterButton
            // 
            this.enterButton.Enabled = false;
            this.enterButton.Location = new System.Drawing.Point(135, 232);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(86, 31);
            this.enterButton.TabIndex = 17;
            this.enterButton.Text = "Enter";
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(36, 232);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(86, 31);
            this.saveButton.TabIndex = 16;
            this.saveButton.Text = "Save As";
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // previousButton
            // 
            this.previousButton.Enabled = false;
            this.previousButton.Location = new System.Drawing.Point(135, 280);
            this.previousButton.Name = "previousButton";
            this.previousButton.Size = new System.Drawing.Size(109, 31);
            this.previousButton.TabIndex = 15;
            this.previousButton.Text = "Previous Record";
            this.previousButton.Click += new System.EventHandler(this.previousButton_Click);
            // 
            // nextButton
            // 
            this.nextButton.Enabled = false;
            this.nextButton.Location = new System.Drawing.Point(259, 280);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(109, 31);
            this.nextButton.TabIndex = 17;
            this.nextButton.Text = "Next Record";
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // openButton
            // 
            this.openButton.Location = new System.Drawing.Point(38, 280);
            this.openButton.Name = "openButton";
            this.openButton.Size = new System.Drawing.Size(86, 31);
            this.openButton.TabIndex = 16;
            this.openButton.Text = "Open File";
            this.openButton.Click += new System.EventHandler(this.openButton_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(39, 328);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(109, 31);
            this.button1.TabIndex = 19;
            this.button1.Text = "Update Record";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(162, 328);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 31);
            this.button2.TabIndex = 20;
            this.button2.Text = "Delete Record";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // FusionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 384);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.previousButton);
            this.Controls.Add(this.openButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.enterButton);
            this.Controls.Add(this.saveButton);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FusionForm";
            this.Text = "Reading a Sequential File";
            this.Load += new System.EventHandler(this.CreateFileForm_Load);
            this.Controls.SetChildIndex(this.saveButton, 0);
            this.Controls.SetChildIndex(this.enterButton, 0);
            this.Controls.SetChildIndex(this.exitButton, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.accountTextBox, 0);
            this.Controls.SetChildIndex(this.firstNameTextBox, 0);
            this.Controls.SetChildIndex(this.lastNameTextBox, 0);
            this.Controls.SetChildIndex(this.balanceTextBox, 0);
            this.Controls.SetChildIndex(this.openButton, 0);
            this.Controls.SetChildIndex(this.previousButton, 0);
            this.Controls.SetChildIndex(this.nextButton, 0);
            this.Controls.SetChildIndex(this.button1, 0);
            this.Controls.SetChildIndex(this.button2, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.Button saveButton;


        // This is from the Read version.  Please note that these 
        // two lines are the only thing I have transferred from the 
        // ReadSequentialAccessFileForm.Designer.cs into the 
        // FusionForm.Designer.cs file so far.

        private System.Windows.Forms.Button previousButton;  // This is a button I added.
        private System.Windows.Forms.Button nextButton;
        private System.Windows.Forms.Button openButton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

