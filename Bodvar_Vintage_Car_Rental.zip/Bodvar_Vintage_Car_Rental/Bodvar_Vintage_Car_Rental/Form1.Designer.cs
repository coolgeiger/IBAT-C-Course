﻿/*
 * Project Name: Bodvar_Vintage_Car_Rental
 * Assignment for C# Course at IBAT College
 * Deadline 7 January 2018
 * 
 * Author: Bodvar Jonsson
 * Email: bjblackbelt@gmail.com
 * Telephone: 0858204129
 * 
 * For a more detailed and comprehensive description on this 
 * project please see the file 'Form1.cs' in this project.
 * 
 */

namespace Bodvar_Vintage_Car_Rental
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.step_down = new System.Windows.Forms.Button();
            this.step_up = new System.Windows.Forms.Button();
            this.delete_current_element = new System.Windows.Forms.Button();
            this.initial_list_element = new System.Windows.Forms.Button();
            this.modify_element = new System.Windows.Forms.Button();
            this.add_element_current_location = new System.Windows.Forms.Button();
            this.add_element_end_of_list = new System.Windows.Forms.Button();
            this.load_from_binary_file = new System.Windows.Forms.Button();
            this.save_to_binary_file = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.exit_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // balanceTextBox
            // 
            this.balanceTextBox.Location = new System.Drawing.Point(162, 234);
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(162, 197);
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(162, 160);
            // 
            // accountTextBox
            // 
            this.accountTextBox.Location = new System.Drawing.Point(162, 123);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(35, 241);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(35, 204);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(35, 167);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(35, 130);
            // 
            // step_down
            // 
            this.step_down.Location = new System.Drawing.Point(17, 280);
            this.step_down.Name = "step_down";
            this.step_down.Size = new System.Drawing.Size(75, 23);
            this.step_down.TabIndex = 17;
            this.step_down.Text = "Step Down";
            this.step_down.UseVisualStyleBackColor = true;
            this.step_down.Click += new System.EventHandler(this.step_down_Click);
            // 
            // step_up
            // 
            this.step_up.Location = new System.Drawing.Point(111, 280);
            this.step_up.Name = "step_up";
            this.step_up.Size = new System.Drawing.Size(75, 23);
            this.step_up.TabIndex = 18;
            this.step_up.Text = "Step Up";
            this.step_up.UseVisualStyleBackColor = true;
            this.step_up.Click += new System.EventHandler(this.step_up_Click);
            // 
            // delete_current_element
            // 
            this.delete_current_element.Location = new System.Drawing.Point(205, 334);
            this.delete_current_element.Name = "delete_current_element";
            this.delete_current_element.Size = new System.Drawing.Size(121, 48);
            this.delete_current_element.TabIndex = 20;
            this.delete_current_element.Text = "Delete Current Element";
            this.delete_current_element.UseVisualStyleBackColor = true;
            this.delete_current_element.Click += new System.EventHandler(this.delete_current_element_Click);
            // 
            // initial_list_element
            // 
            this.initial_list_element.Location = new System.Drawing.Point(17, 398);
            this.initial_list_element.Name = "initial_list_element";
            this.initial_list_element.Size = new System.Drawing.Size(169, 23);
            this.initial_list_element.TabIndex = 21;
            this.initial_list_element.Text = "Go to Initial Element of List";
            this.initial_list_element.UseVisualStyleBackColor = true;
            this.initial_list_element.Click += new System.EventHandler(this.initial_list_element_Click);
            // 
            // modify_element
            // 
            this.modify_element.Location = new System.Drawing.Point(205, 279);
            this.modify_element.Name = "modify_element";
            this.modify_element.Size = new System.Drawing.Size(121, 39);
            this.modify_element.TabIndex = 22;
            this.modify_element.Text = "Enter Modification to Current Element";
            this.modify_element.UseVisualStyleBackColor = true;
            this.modify_element.Click += new System.EventHandler(this.modify_element_Click);
            // 
            // add_element_current_location
            // 
            this.add_element_current_location.Location = new System.Drawing.Point(17, 320);
            this.add_element_current_location.Name = "add_element_current_location";
            this.add_element_current_location.Size = new System.Drawing.Size(169, 23);
            this.add_element_current_location.TabIndex = 23;
            this.add_element_current_location.Text = "Add Element to Current Location";
            this.add_element_current_location.UseVisualStyleBackColor = true;
            this.add_element_current_location.Click += new System.EventHandler(this.add_element_current_location_Click);
            // 
            // add_element_end_of_list
            // 
            this.add_element_end_of_list.Location = new System.Drawing.Point(17, 359);
            this.add_element_end_of_list.Name = "add_element_end_of_list";
            this.add_element_end_of_list.Size = new System.Drawing.Size(169, 23);
            this.add_element_end_of_list.TabIndex = 24;
            this.add_element_end_of_list.Text = "Add Element to End of List";
            this.add_element_end_of_list.UseVisualStyleBackColor = true;
            this.add_element_end_of_list.Click += new System.EventHandler(this.add_element_end_of_list_Click);
            // 
            // load_from_binary_file
            // 
            this.load_from_binary_file.Location = new System.Drawing.Point(17, 438);
            this.load_from_binary_file.Name = "load_from_binary_file";
            this.load_from_binary_file.Size = new System.Drawing.Size(122, 36);
            this.load_from_binary_file.TabIndex = 25;
            this.load_from_binary_file.Text = "Load from Binary File";
            this.load_from_binary_file.UseVisualStyleBackColor = true;
            this.load_from_binary_file.Click += new System.EventHandler(this.load_from_binary_file_Click);
            // 
            // save_to_binary_file
            // 
            this.save_to_binary_file.Location = new System.Drawing.Point(158, 438);
            this.save_to_binary_file.Name = "save_to_binary_file";
            this.save_to_binary_file.Size = new System.Drawing.Size(121, 36);
            this.save_to_binary_file.TabIndex = 26;
            this.save_to_binary_file.Text = "Save to Binary File";
            this.save_to_binary_file.UseVisualStyleBackColor = true;
            this.save_to_binary_file.Click += new System.EventHandler(this.save_to_binary_file_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Bodvar_Vintage_Car_Rental.Properties.Resources.small_bluegreen_car;
            this.pictureBox1.Location = new System.Drawing.Point(38, 43);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(132, 62);
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // exit_button
            // 
            this.exit_button.Location = new System.Drawing.Point(298, 438);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(75, 35);
            this.exit_button.TabIndex = 27;
            this.exit_button.Text = "Exit";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 486);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.save_to_binary_file);
            this.Controls.Add(this.load_from_binary_file);
            this.Controls.Add(this.add_element_end_of_list);
            this.Controls.Add(this.add_element_current_location);
            this.Controls.Add(this.modify_element);
            this.Controls.Add(this.initial_list_element);
            this.Controls.Add(this.delete_current_element);
            this.Controls.Add(this.step_up);
            this.Controls.Add(this.step_down);
            this.Name = "Form1";
            this.Text = "Bodvar\'s Vintage Car Rental";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.accountTextBox, 0);
            this.Controls.SetChildIndex(this.firstNameTextBox, 0);
            this.Controls.SetChildIndex(this.lastNameTextBox, 0);
            this.Controls.SetChildIndex(this.balanceTextBox, 0);
            this.Controls.SetChildIndex(this.step_down, 0);
            this.Controls.SetChildIndex(this.step_up, 0);
            this.Controls.SetChildIndex(this.delete_current_element, 0);
            this.Controls.SetChildIndex(this.initial_list_element, 0);
            this.Controls.SetChildIndex(this.modify_element, 0);
            this.Controls.SetChildIndex(this.add_element_current_location, 0);
            this.Controls.SetChildIndex(this.add_element_end_of_list, 0);
            this.Controls.SetChildIndex(this.load_from_binary_file, 0);
            this.Controls.SetChildIndex(this.save_to_binary_file, 0);
            this.Controls.SetChildIndex(this.pictureBox1, 0);
            this.Controls.SetChildIndex(this.exit_button, 0);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button step_down;
        private System.Windows.Forms.Button step_up;
        private System.Windows.Forms.Button delete_current_element;
        private System.Windows.Forms.Button initial_list_element;
        private System.Windows.Forms.Button modify_element;
        private System.Windows.Forms.Button add_element_current_location;
        private System.Windows.Forms.Button add_element_end_of_list;
        private System.Windows.Forms.Button load_from_binary_file;
        private System.Windows.Forms.Button save_to_binary_file;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button exit_button;
    }
}

