﻿/*
 * Project Name: Bodvar_Vintage_Car_Rental
 * Assignment for C# Course at IBAT College
 * Deadline 7 January 2018
 * 
 * Author: Bodvar Jonsson
 * Email: bjblackbelt@gmail.com
 * Telephone: 0858204129
 * 
 * For a more detailed and comprehensive description on this 
 * project please see the file 'Form1.cs' in this project.
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bodvar_Vintage_Car_Rental
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
