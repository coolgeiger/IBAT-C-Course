﻿namespace Bodvar_Jan_5_Vintage_Car_Rental
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.previous_button = new System.Windows.Forms.Button();
            this.next_button = new System.Windows.Forms.Button();
            this.update_button = new System.Windows.Forms.Button();
            this.first_button = new System.Windows.Forms.Button();
            this.last_button = new System.Windows.Forms.Button();
            this.delete_button = new System.Windows.Forms.Button();
            this.add_button = new System.Windows.Forms.Button();
            this.load_file = new System.Windows.Forms.Button();
            this.s_button = new System.Windows.Forms.Button();
            this.s_as_button = new System.Windows.Forms.Button();
            this.exit_button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // balanceTextBox
            // 
            this.balanceTextBox.Location = new System.Drawing.Point(162, 228);
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(162, 191);
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(162, 154);
            // 
            // accountTextBox
            // 
            this.accountTextBox.Location = new System.Drawing.Point(162, 117);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(35, 235);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(35, 198);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(35, 161);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(35, 124);
            // 
            // previous_button
            // 
            this.previous_button.Location = new System.Drawing.Point(38, 267);
            this.previous_button.Name = "previous_button";
            this.previous_button.Size = new System.Drawing.Size(75, 23);
            this.previous_button.TabIndex = 17;
            this.previous_button.Text = "Previous";
            this.previous_button.UseVisualStyleBackColor = true;
            this.previous_button.Click += new System.EventHandler(this.previous_button_Click);
            // 
            // next_button
            // 
            this.next_button.Location = new System.Drawing.Point(133, 266);
            this.next_button.Name = "next_button";
            this.next_button.Size = new System.Drawing.Size(75, 23);
            this.next_button.TabIndex = 18;
            this.next_button.Text = "Next";
            this.next_button.UseVisualStyleBackColor = true;
            this.next_button.Click += new System.EventHandler(this.next_button_Click);
            // 
            // update_button
            // 
            this.update_button.Location = new System.Drawing.Point(230, 265);
            this.update_button.Name = "update_button";
            this.update_button.Size = new System.Drawing.Size(99, 23);
            this.update_button.TabIndex = 19;
            this.update_button.Text = "Update Record";
            this.update_button.UseVisualStyleBackColor = true;
            this.update_button.Click += new System.EventHandler(this.update_button_Click);
            // 
            // first_button
            // 
            this.first_button.Location = new System.Drawing.Point(38, 309);
            this.first_button.Name = "first_button";
            this.first_button.Size = new System.Drawing.Size(75, 23);
            this.first_button.TabIndex = 20;
            this.first_button.Text = "First";
            this.first_button.UseVisualStyleBackColor = true;
            this.first_button.Click += new System.EventHandler(this.first_button_Click);
            // 
            // last_button
            // 
            this.last_button.Location = new System.Drawing.Point(133, 308);
            this.last_button.Name = "last_button";
            this.last_button.Size = new System.Drawing.Size(75, 23);
            this.last_button.TabIndex = 21;
            this.last_button.Text = "Last";
            this.last_button.UseVisualStyleBackColor = true;
            this.last_button.Click += new System.EventHandler(this.last_button_Click);
            // 
            // delete_button
            // 
            this.delete_button.Location = new System.Drawing.Point(230, 307);
            this.delete_button.Name = "delete_button";
            this.delete_button.Size = new System.Drawing.Size(99, 23);
            this.delete_button.TabIndex = 22;
            this.delete_button.Text = "Delete Record";
            this.delete_button.UseVisualStyleBackColor = true;
            this.delete_button.Click += new System.EventHandler(this.delete_button_Click);
            // 
            // add_button
            // 
            this.add_button.Location = new System.Drawing.Point(349, 306);
            this.add_button.Name = "add_button";
            this.add_button.Size = new System.Drawing.Size(96, 23);
            this.add_button.TabIndex = 23;
            this.add_button.Text = "Add Record";
            this.add_button.UseVisualStyleBackColor = true;
            this.add_button.Click += new System.EventHandler(this.add_button_Click);
            // 
            // load_file
            // 
            this.load_file.Location = new System.Drawing.Point(38, 352);
            this.load_file.Name = "load_file";
            this.load_file.Size = new System.Drawing.Size(75, 23);
            this.load_file.TabIndex = 24;
            this.load_file.Text = "Load";
            this.load_file.UseVisualStyleBackColor = true;
            this.load_file.Click += new System.EventHandler(this.load_file_Click);
            // 
            // s_button
            // 
            this.s_button.Location = new System.Drawing.Point(133, 351);
            this.s_button.Name = "s_button";
            this.s_button.Size = new System.Drawing.Size(75, 23);
            this.s_button.TabIndex = 25;
            this.s_button.Text = "Save";
            this.s_button.UseVisualStyleBackColor = true;
            this.s_button.Click += new System.EventHandler(this.s_button_Click);
            // 
            // s_as_button
            // 
            this.s_as_button.Location = new System.Drawing.Point(230, 351);
            this.s_as_button.Name = "s_as_button";
            this.s_as_button.Size = new System.Drawing.Size(75, 23);
            this.s_as_button.TabIndex = 26;
            this.s_as_button.Text = "Save As";
            this.s_as_button.UseVisualStyleBackColor = true;
            this.s_as_button.Click += new System.EventHandler(this.s_as_button_Click);
            // 
            // exit_button
            // 
            this.exit_button.Location = new System.Drawing.Point(329, 350);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(75, 23);
            this.exit_button.TabIndex = 27;
            this.exit_button.Text = "Exit";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Bodvar_Jan_5_Vintage_Car_Rental.Properties.Resources.small_bluegreen_car;
            this.pictureBox1.Location = new System.Drawing.Point(38, 43);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 68);
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 478);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.s_as_button);
            this.Controls.Add(this.s_button);
            this.Controls.Add(this.load_file);
            this.Controls.Add(this.add_button);
            this.Controls.Add(this.delete_button);
            this.Controls.Add(this.last_button);
            this.Controls.Add(this.first_button);
            this.Controls.Add(this.update_button);
            this.Controls.Add(this.next_button);
            this.Controls.Add(this.previous_button);
            this.Name = "Form1";
            this.Text = "Bodvar\'s Vintage Car Rental";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.accountTextBox, 0);
            this.Controls.SetChildIndex(this.firstNameTextBox, 0);
            this.Controls.SetChildIndex(this.lastNameTextBox, 0);
            this.Controls.SetChildIndex(this.balanceTextBox, 0);
            this.Controls.SetChildIndex(this.previous_button, 0);
            this.Controls.SetChildIndex(this.next_button, 0);
            this.Controls.SetChildIndex(this.update_button, 0);
            this.Controls.SetChildIndex(this.first_button, 0);
            this.Controls.SetChildIndex(this.last_button, 0);
            this.Controls.SetChildIndex(this.delete_button, 0);
            this.Controls.SetChildIndex(this.add_button, 0);
            this.Controls.SetChildIndex(this.load_file, 0);
            this.Controls.SetChildIndex(this.s_button, 0);
            this.Controls.SetChildIndex(this.s_as_button, 0);
            this.Controls.SetChildIndex(this.exit_button, 0);
            this.Controls.SetChildIndex(this.pictureBox1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button previous_button;
        private System.Windows.Forms.Button next_button;
        private System.Windows.Forms.Button update_button;
        private System.Windows.Forms.Button first_button;
        private System.Windows.Forms.Button last_button;
        private System.Windows.Forms.Button delete_button;
        private System.Windows.Forms.Button add_button;
        private System.Windows.Forms.Button load_file;
        private System.Windows.Forms.Button s_button;
        private System.Windows.Forms.Button s_as_button;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

