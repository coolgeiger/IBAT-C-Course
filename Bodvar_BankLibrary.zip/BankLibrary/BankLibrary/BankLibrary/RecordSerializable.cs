/*
 * Author: Bodvar Jonsson
 * Email: bjblackbelt@gmail.com
 * Telephone: 0858204129
 * 
 * Part of assignment for the C# course at IBAT College
 * Deadline 7 January 2018
 * 
 * For more information please see description in 'BankUIForm.cs' in this folder
 * ad 'Form1.cs' in the folder 'Bodvar_Vintage_Car_Rental'.
 * 
 */

// Fig. 17.8: RecordSerializable.cs
// Serializable class that represents a data record.
using System;

namespace BankLibrary
{
   [Serializable]
   public class RecordSerializable
   {
      public int Account { get; set; }
      public string FirstName { get; set; }
      public string LastName { get; set; }
      public decimal Balance { get; set; }

      // default constructor sets members to default values
      public RecordSerializable()
         : this(0, string.Empty, string.Empty, 0M) { }

      // overloaded constructor sets members to parameter values
      public RecordSerializable(int account, string firstName,
         string lastName, decimal balance)
      {
         Account = account;
         FirstName = firstName;
         LastName = lastName;
         Balance = balance;
      }
   }
}


  
                 
                             
                                                                         
       
              
            
          
    
     
          
          
                         
   
