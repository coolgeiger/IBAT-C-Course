﻿/*
 * Author: Bodvar Jonsson
 * Email: bjblackbelt@gmail.com
 * Telephone: 0858204129
 * 
 * Part of assignment for the C# course at IBAT College
 * Deadline 7 January 2018
 * 
 * For more information please see description in 'BankUIForm.cs' in this folder
 * ad 'Form1.cs' in the folder 'Bodvar_Vintage_Car_Rental'.
 * 
 */

using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace BankLibrary
{
   static class Program
   {
      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main( string[] args )
      {
         Application.EnableVisualStyles();
         Application.Run(new BankUIForm());
      }
   }
}