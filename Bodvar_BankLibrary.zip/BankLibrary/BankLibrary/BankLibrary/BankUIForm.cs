﻿/*
 * Author: Bodvar Jonsson
 * Email: bjblackbelt@gmail.com
 * Telephone: 0858204129
 * 
 * Part of assignment for the C# course at IBAT College
 * Deadline 7 January 2018
 * 
 * Brief description:
 * 
 * This file is refrenced to from files in the project 'Bodvar_Vintage_Car_Rental'
 * Form a general description of the project in its entirity please see the 
 * beginning of the file 'Form1.cs' in the folder 'Bodvar_Vintage_Car_Rental' 
 * containing the project of the same name:
 *
 *
 * Although the name of the solution and the files in it are identical to 
 * the ones provided in the course material for the C# course at IBAT College, 
 * some modifications have been made. This manifests itself in label names,  
 * titles, fonts etc.  This solution and its files will be used as part of 
 * the assignment for aforementioned C# course at IBAT College, 
 * wintersemester 2017-2018, deadline 7 January 2018.
 * 
 * To avoid confusion and references possibly going astray in the main part 
 * of the assignment to the parent forms, .dll files etc., it was decided to 
 * stick to the original names of the files and variables in the BankLibrary
 * Solution.  In that way the development of the main project would go smoother
 * and one could concentrate on errors pertaining to it itself.
 * 
 * With a robost entire solution in place it can always be possible to create 
 * a new library and a new main project with modified and/or additional features
 * such as more variables, diferent variable types etc.
 */

// Fig. 17.2: BankUIForm.cs
// A reusable Windows Form for the examples in this chapter.
using System;
using System.Windows.Forms;

namespace BankLibrary
{
   public partial class BankUIForm : Form
   {
      protected int TextBoxCount { get; set; } = 4; // number of TextBoxes

      // enumeration constants specify TextBox indices
      public enum TextBoxIndices { Account, First, Last, Balance }

      // parameterless constructor
      public BankUIForm()
      {
         InitializeComponent();
      }

      // clear all TextBoxes
      public void ClearTextBoxes()
      {
         // iterate through every Control on form
         foreach (Control guiControl in Controls)
         {
            // if Control is TextBox, clear it
            (guiControl as TextBox)?.Clear();
         }
      }

      // set text box values to string-array values
      public void SetTextBoxValues(string[] values)
      {
         // determine whether string array has correct length
         if (values.Length != TextBoxCount)
         {
            // throw exception if not correct length
            throw (new ArgumentException(
               $"There must be {TextBoxCount} strings in the array",
               nameof(values)));
         }  
         else // set array values if array has correct length
         {
            // set array values to TextBox values
            accountTextBox.Text = values[(int)TextBoxIndices.Account];
            firstNameTextBox.Text = values[(int)TextBoxIndices.First];
            lastNameTextBox.Text = values[(int)TextBoxIndices.Last];
            balanceTextBox.Text = values[(int)TextBoxIndices.Balance];
         }
      }

      // return TextBox values as string array
      public string[] GetTextBoxValues()
      {
         return new string[] {
            accountTextBox.Text, firstNameTextBox.Text,
            lastNameTextBox.Text, balanceTextBox.Text};
      }
   }
}



  
                 
                             
                                                                         
       
              
            
          
    
     
          
          
                         
   