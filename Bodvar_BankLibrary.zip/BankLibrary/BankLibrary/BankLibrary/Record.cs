// Fig. 17.3: Record.cs
/*
 * Author: Bodvar Jonsson
 * Email: bjblackbelt@gmail.com
 * Telephone: 0858204129
 * 
 * Part of assignment for the C# course at IBAT College
 * Deadline 7 January 2018
 * 
 * For more information please see description in 'BankUIForm.cs' in this folder
 * ad 'Form1.cs' in the folder 'Bodvar_Vintage_Car_Rental'.
 * 
 */

// Class that represents a data record.
namespace BankLibrary
{
   public class Record
   {
      public int Account { get; set; }
      public string FirstName { get; set; }
      public string LastName { get; set; }
      public decimal Balance { get; set; }

      // parameterless constructor sets members to default values
      public Record() : this(0, string.Empty, string.Empty, 0M) { }

      // overloaded constructor sets members to parameter values
      public Record(int account, string firstName,
         string lastName, decimal balance)
      {
         Account = account;
         FirstName = firstName;
         LastName = lastName;
         Balance = balance;
      }
   }
}



  
                 
                             
                                                                         
       
              
            
          
    
     
          
          
                         
   